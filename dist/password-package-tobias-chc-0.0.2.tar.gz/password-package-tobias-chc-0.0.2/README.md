# Password Package

This package its just for understand how packaging works in Python and contains
a small script to generate a random password for a given length.
